package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;

@Component("cs")
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepo;
	
	public Customer create(Customer cust) {
		// TODO Auto-generated method stub
		return customerRepo.save(cust);
	}
	
	public List<Customer> read() {
		// TODO Auto-generated method stub
		return customerRepo.findAll();
	}

	public Customer read(String customerId) {
		// TODO Auto-generated method stub
		return customerRepo.findById(customerId).get();
	}

	public Customer update(Customer cust) {
		// TODO Auto-generated method stub
		return customerRepo.save(cust);
	}

	public void delete(String customerId) {
		// TODO Auto-generated method stub
		customerRepo.delete(read(customerId));
	}

}
