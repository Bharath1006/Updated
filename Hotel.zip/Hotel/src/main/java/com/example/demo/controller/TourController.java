
package com.example.demo.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Customer;
import com.example.demo.entity.Tour;
import com.example.demo.service.CustomerService;
import com.example.demo.service.TourService;
import com.sun.el.parser.ParseException;

@RestController
@CrossOrigin(origins = {"http://http://localhost:4200/", "*"})
@RequestMapping("/Tour")
public class TourController {
	@Autowired
	 TourService ts;
	@Autowired
	CustomerService cs;
	
	//public Booking addBooking(@RequestParam("bookingId")String bookingId,@RequestParam("customerId") String customerId, @RequestParam("hotelId")String hotelId, @RequestParam("bookingType")String bookingType, @RequestParam("arrivalDate")String arrivalDate,@RequestParam("departureDate")String departureDate, @RequestParam("noOfPeople")Integer noOfPeople, @RequestParam("totalAmount")Integer totalAmount ) throws ParseException, IOException, java.text.ParseException
	//{
	
	
	@PostMapping("/")
	public Tour addTour(@RequestParam("guideId")String guideId,@RequestParam("customerId")String customerId,@RequestParam("guideName")String guideName,@RequestParam("guidePhoneNo")String guidePhoneNo)
	{
		
		Customer customer = cs.read(customerId);
		Tour Tour=new Tour();
		Tour.setGuideId(guideId);
		Tour.setCustomer(customer);
		Tour.setGuideName(guideName);
		Tour.setGuidePhoneNo(guidePhoneNo);
		return ts.create(Tour);
	}
	
//	@PostMapping("/")
//	public Tour addTour(@RequestBody Tour Tour)
//	{
//		return ts.create(Tour);
//	}
	@GetMapping("/")
	public List<Tour> getAllToures()
	{
		return ts.read();
	}
	@GetMapping("/{guideid}")
	public Tour findTourById(@PathVariable("guideid") String guideid)
	{
		return ts.read(guideid);
	}
	@PutMapping("/")
	public Tour modifyTour(@RequestParam("guideId")String guideId,@RequestParam("customerId")String customerId,@RequestParam("guideName")String guideName,@RequestParam("guidePhoneNo")String guidePhoneNo)
	{
		Customer customer = cs.read(customerId);
		Tour Tour=new Tour();
		Tour.setGuideId(guideId);
		Tour.setCustomer(customer);
		Tour.setGuideName(guideName);
		Tour.setGuidePhoneNo(guidePhoneNo);
		return ts.update(Tour);
	}
	@DeleteMapping("/{guideid}")
	public void removeTour(@PathVariable("guideid")String guideid)
	{
		ts.delete(guideid);
	}
}
