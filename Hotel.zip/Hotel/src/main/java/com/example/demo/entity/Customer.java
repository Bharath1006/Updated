package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="maithri")
public class Customer
{
	@Id
	private String customerId;
	private String customerName;
	private String userName;
	private String password;
	private String city;
	private String phoneNo;
	private String emailId;
	public Customer() {}
	public Customer(String customerId, String customerName, String userName, String password, String city,
			String phoneNo, String emailId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.userName = userName;
		this.password = password;
		this.city = city;
		this.phoneNo = phoneNo;
		this.emailId = emailId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", userName=" + userName
				+ ", password=" + password + ", city=" + city + ", phoneNo=" + phoneNo + ", emailId=" + emailId + "]";
	}

}
