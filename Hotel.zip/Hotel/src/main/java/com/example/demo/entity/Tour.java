
package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TOUR")
public class Tour {
	@Id
	private String guideId;
	@ManyToOne(targetEntity = Customer.class)
	@JoinColumn(name = "customerId")
	private Customer customer;
	private String guideName;
	private String guidePhoneNo;

	public Tour() {}

	public Tour(String guideId, Customer customer, String guideName, String guidePhoneNo) {
		super();
		this.guideId = guideId;
		this.customer = customer;
		this.guideName = guideName;
		this.guidePhoneNo = guidePhoneNo;
	}

	public String getGuideId() {
		return guideId;
	}

	public void setGuideId(String guideId) {
		this.guideId = guideId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getGuideName() {
		return guideName;
	}

	public void setGuideName(String guideName) {
		this.guideName = guideName;
	}

	public String getGuidePhoneNo() {
		return guidePhoneNo;
	}

	public void setGuidePhoneNo(String guidePhoneNo) {
		this.guidePhoneNo = guidePhoneNo;
	}

	@Override
	public String toString() {
		return "Tour [guideId=" + guideId + ", customer=" + customer + ", guideName=" + guideName + ", guidePhoneNo="
				+ guidePhoneNo + "]";
	}

	
	
}
