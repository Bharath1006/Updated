package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Admin;
import com.example.demo.service.AdminService;


@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class AdminController {
	@Autowired
	AdminService bs;
	
	@GetMapping("/")
	public List<Admin> read()
	{
		List<Admin> admins = bs.read();
		return admins;
	}
	@GetMapping("/{adminId}")
	public Admin findAdminById(@PathVariable("adminId") String adminId)
	{
		return bs.read(adminId);
	}
	@PostMapping("/")
	public Admin addAdmin(@RequestBody Admin admin) 
	{
		return bs.create(admin);
	}
	@PutMapping("/")
	public Admin modifyAdmin(@RequestBody Admin admin) 
	{
		return bs.update(admin);
	}
	@DeleteMapping("{adminId}")
	public void deleteAdmin(@PathVariable("adminId") String adminId)
	{
		bs.delete(adminId);
	}
}
