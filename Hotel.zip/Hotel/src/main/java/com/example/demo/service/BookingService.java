package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Booking;
import com.example.demo.repository.BookingRepository;

@Component("bs")
public class BookingService {
	@Autowired
	BookingRepository br;
	public Booking create(Booking booking) {
		return br.save(booking);
	}
	public List<Booking> read() {
		return br.findAll();
	}
	public Booking read(String bookingId) {
		return br.findById(bookingId).get();
	}
	public Booking update(Booking booking) {
		return br.save(booking);
	}
	public void delete(String bookingId) {
		br.delete(read(bookingId));
	}
	

}
