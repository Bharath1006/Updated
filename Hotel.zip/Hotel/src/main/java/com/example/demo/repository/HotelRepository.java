package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Hotel;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, String> {
	@Query("select h from Hotel h where h.city=:city")
	List<Hotel> findHotelsByCity(@Param("city")String city);

}
