package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "HOTEL")
public class Hotel {
		
		@Id
		private String hotelId;
		private String hotelName;
		private String city;
		private Integer noOfRoomsAvailable;
		
		public Hotel() {}

		public Hotel(String hotelId, String hotelName, String city, Integer noOfRoomsAvailable) {
			super();
			this.hotelId = hotelId;
			this.hotelName = hotelName;
			this.city = city;
			this.noOfRoomsAvailable = noOfRoomsAvailable;
		}

		public String getHotelId() {
			return hotelId;
		}

		public void setHotelId(String hotelId) {
			this.hotelId = hotelId;
		}

		public String getHotelName() {
			return hotelName;
		}

		public void setHotelName(String hotelName) {
			this.hotelName = hotelName;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public Integer getNoOfRoomsAvailable() {
			return noOfRoomsAvailable;
		}

		public void setNoOfRoomsAvailable(Integer noOfRoomsAvailable) {
			this.noOfRoomsAvailable = noOfRoomsAvailable;
		}

		@Override
		public String toString() {
			return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", city=" + city + ", noOfRoomsAvailable="
					+ noOfRoomsAvailable + "]";
		}

		
		
		
}
