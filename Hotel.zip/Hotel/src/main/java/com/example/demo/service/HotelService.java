package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Hotel;
import com.example.demo.repository.HotelRepository;

@Component("hs")
public class HotelService {
	
	@Autowired
	private HotelRepository hr;
	
	public Hotel create(Hotel Hotel)
	{
		return hr.save(Hotel);
		
	}
	public List<Hotel> read() 
	{
		return hr.findAll();
	}
	public Hotel read(String hotelId) 
	{
		return hr.findById(hotelId).get();
	}
	public Hotel update(Hotel Hotel) 
	{
		return hr.save(Hotel);
	}
	public void delete(String hotelId) 
	{
		hr.delete(read(hotelId));
	}

}
