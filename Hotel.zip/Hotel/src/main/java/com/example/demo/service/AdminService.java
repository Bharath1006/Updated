package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Admin;
import com.example.demo.repository.AdminRepository;


@Component("as")
public class AdminService {
	@Autowired
	AdminRepository ar;
	public Admin create(Admin admin) {
		return ar.save(admin);
	}
	public List<Admin> read() {
		return ar.findAll();
	}
	public Admin read(String adminId) {
		return ar.findById(adminId).get();
	}
	public Admin update(Admin admin) {
		return ar.save(admin);
	}
	public void delete(String adminId) {
		ar.delete(read(adminId));
	}
}
