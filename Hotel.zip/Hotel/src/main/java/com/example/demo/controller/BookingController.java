package com.example.demo.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Customer;
import com.example.demo.entity.Hotel;
import com.example.demo.service.BookingService;
import com.example.demo.service.CustomerService;
import com.example.demo.service.HotelService;
import com.sun.el.parser.ParseException;

@RestController
@RequestMapping("/booking")
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class BookingController {
	@Autowired
	BookingService bs;
	@Autowired
	CustomerService cs;
	@Autowired
	HotelService hs;
	
	@GetMapping("/")
	public List<Booking> read()
	{
		List<Booking> bookings = bs.read();
		return bookings;
	}
	@GetMapping("/{bookingId}")
	public Booking findBookingById(@PathVariable("bookingId") String bookingId)
	{
		return bs.read(bookingId);
	}
//	@PostMapping("/")
//	public Booking addBooking(@RequestBody Booking booking) //individual parameters using @RTequestParam. in angular use formdata
//	{
//		//find customer object using customerId
//		
//		System.out.println(booking);
//		return bs.create(booking);
//	}
	
	@PostMapping("/")
	public Booking addBooking(@RequestParam("bookingId")String bookingId,@RequestParam("customerId") String customerId, @RequestParam("hotelId")String hotelId, @RequestParam("bookingType")String bookingType, @RequestParam("arrivalDate")String arrivalDate,@RequestParam("departureDate")String departureDate, @RequestParam("noOfPeople")Integer noOfPeople, @RequestParam("totalAmount")Integer totalAmount ) throws ParseException, IOException, java.text.ParseException
	{
//		System.out.println("add booking \n");
//		System.out.println(bookingId);
//		System.out.println(customerId);
//		System.out.println(hotelId);
//		System.out.println(bookingType);
//		System.out.println(arrivalDate);
//		System.out.println(departureDate);
		
	Customer customer = cs.read(customerId);
	Hotel hotel = hs.read(hotelId);
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
	Date Adate = sdf.parse(arrivalDate);
	SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd");
	Date Ddate = sdf2.parse(departureDate);
//	Booking booking=new Booking(bookingId, customer, hotel, bookingType, arrivalDate, departureDate, noOfPeople, totalAmount);
	Booking booking=new Booking();
	booking.setBookingId(bookingId);
	booking.setCustomer(customer);
	booking.setHotel(hotel);
	booking.setBookingType(bookingType);
	booking.setArrivalDate(Adate);
	booking.setDepartureDate(Ddate);
	booking.setNoOfPeople(noOfPeople);
	booking.setTotalAmount(totalAmount);
	System.out.println(booking);
	return bs.create(booking);
	}
	
//	@PutMapping("/")
//	public Booking modifyBooking(@RequestBody Booking booking) 
//	{
//		return bs.update(booking);
//	}
	
	@PutMapping("/")
	public Booking modifyBooking(@RequestParam("bookingId")String bookingId,@RequestParam("customerId") String customerId, @RequestParam("hotelId")String hotelId, @RequestParam("bookingType")String bookingType, @RequestParam("arrivalDate")String arrivalDate,@RequestParam("departureDate")String departureDate, @RequestParam("noOfPeople")Integer noOfPeople, @RequestParam("totalAmount")Integer totalAmount) throws java.text.ParseException 
	{
		Customer customer = cs.read(customerId);
		Hotel hotel = hs.read(hotelId);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date Adate = sdf.parse(arrivalDate);
		SimpleDateFormat sdf2=new SimpleDateFormat("yyyy-MM-dd");
		Date Ddate = sdf2.parse(departureDate);
//		Booking booking=new Booking(bookingId, customer, hotel, bookingType, arrivalDate, departureDate, noOfPeople, totalAmount);
		Booking booking=new Booking();
		booking.setBookingId(bookingId);
		booking.setCustomer(customer);
		booking.setHotel(hotel);
		booking.setBookingType(bookingType);
		booking.setArrivalDate(Adate);
		booking.setDepartureDate(Ddate);
		booking.setNoOfPeople(noOfPeople);
		booking.setTotalAmount(totalAmount);
		return bs.update(booking);
	}
	@DeleteMapping("{bookingId}")
	public void deleteBooking(@PathVariable("bookingId") String bookingId)
	{
		bs.delete(bookingId);
	}
}
