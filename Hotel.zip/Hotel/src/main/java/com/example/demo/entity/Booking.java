package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="BOOKING")
public class Booking {
@Id
//@GeneratedValue(strategy = GenerationType.AUTO)
private String bookingId;
@ManyToOne(targetEntity = Hotel.class)
@JoinColumn(name = "hotelId")
private Hotel hotel;
// private String hotelId;
//@OneToOne(fetch = FetchType.LAZY)
@ManyToOne(targetEntity = Customer.class)
@JoinColumn(name = "customerId")
private Customer customer;
private String bookingType;
private Date arrivalDate;
private Date departureDate;
private Integer noOfPeople;
private Integer totalAmount;
//	@Transient
//	private SimpleDateFormat sdf;
//	
	public Booking() {
	//	sdf=new SimpleDateFormat("yyyy-MM-dd");
	}
	public Booking(String bookingId, Hotel hotel, Customer customer, String bookingType, Date arrivalDate,
			Date departureDate, Integer noOfPeople, Integer totalAmount) {
		super();
		this.bookingId = bookingId;
		this.hotel = hotel;
		this.customer = customer;
		this.bookingType = bookingType;
		this.arrivalDate = arrivalDate;
		this.departureDate = departureDate;
		this.noOfPeople = noOfPeople;
		this.totalAmount = totalAmount;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getBookingType() {
		return bookingType;
	}
	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}
	public Date getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public Integer getNoOfPeople() {
		return noOfPeople;
	}
	public void setNoOfPeople(Integer noOfPeople) {
		this.noOfPeople = noOfPeople;
	}
	public Integer getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Integer totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", hotel=" + hotel + ", customer=" + customer + ", bookingType="
				+ bookingType + ", arrivalDate=" + arrivalDate + ", departureDate=" + departureDate + ", noOfPeople="
				+ noOfPeople + ", totalAmount=" + totalAmount + "]";
	}


	

}
