import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customerForm:any;
  customers:any;
  constructor(private fb: FormBuilder, private bs: CustomerService) {
    this.customerForm = this.fb.group({
      customerId: [''],
      customerName: [''],
      userName: [''],
      password:[''],
      Rpassword:[''],
      city:[''],
      phoneNo:[''],
      emailId:['']
    })
  }
  ngOnInit(): void {
    this.getAllCustomers();
  }
  getAllCustomers() {
    this.bs.getAllCustomer().subscribe((data:any) => {
      console.log(data);
      this.customers = data;
    });
  }
  fnSelect(customerId: string) {
    this.bs.findCustomerById(customerId).subscribe((data:any) => {
      console.log(data);
      // alert(JSON.stringify(data))
      this.customerForm.patchValue(data);
    });
  }

  fnFind() {
    var customerId = this.customerForm.controls.customerId.value;
    this.fnSelect(customerId);
  }

  fnAdd() {
    var branch = this.customerForm.value;
    // this.bs.addBranch(branch).subscribe(this.fnCallBack);    
    this.bs.addCustomer(this.customers).subscribe((data:any) => {
      console.log(data);
      this.getAllCustomers();
    });
  }
  fnModify() {
    var branch = this.customerForm.value;
    this.bs.modifyCustomer(branch).subscribe((data:any) => {
      console.log(data);
      this.getAllCustomers();
    });
  }
  fnDelete() {
    var customerId = this.customerForm.controls.customerId.value;
    this.bs.deleteCustomer(customerId).subscribe((data:any) => {
      console.log(data);
      this.getAllCustomers();
    });
  }
}

