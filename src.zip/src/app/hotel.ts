export class Hotel {
    hotelId:string="";
    hotelName:string="";
    city:string="";
    noOFRoomsAvail:number=0;
}
