import { Customer } from "./customer";

export class Tour {
    guideId:string="";
    customer:Customer=new Customer(); 
    guideName:string="";
    guidePhoneNo:string="";
}
