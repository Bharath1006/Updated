import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HotelService } from '../hotel.service';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {

  hotelForm: any;
  hotels: any;
  formGroup:any;
  
  constructor(private fb:FormBuilder, private hs:HotelService) { 
    this.hotelForm=this.fb.group({
      hotelId:['', [Validators.required,Validators.minLength(6),Validators.maxLength(6),Validators.pattern]],
      // customerId:[''],
      hotelName:['',[Validators.required,Validators.minLength(5),Validators.maxLength(20),Validators.pattern]],
      city:[''],
      noOfRoomsAvailable:['']
    },{validators:this.hotelIdValidator()});
  }

  // ,this:this.hotelNameValidator()
  hotelIdValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.hotelId.errors && !formGroup.controls.hotelId.errors.hotelIdValidator)
        return;
      var status =false;
      var hotelId= formGroup.controls.hotelId.value;
      //alert(hotelId.substring(0,1));
      if (hotelId.substring(0, 1) != 'H' && hotelId.substring(0, 1) != 'h') {
        status = true;
      } else {
        // var str = hotelId.substring(1);
        // if (isNaN(num))
          // status = true;
      }
      if (status)
        formGroup.controls.hotelId.setErrors({ 'hotelIdValidator': true });
      else
        formGroup.controls.hotelId.setErrors(null);
    }
  }
  hotelNameValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.hotelName.errors && !formGroup.controls.hotelName.errors.hotelNameValidator)
        return;
      var status =false;
      var hotelName= formGroup.controls.hotelName.value;
      //alert(hotelId.substring(0,1));
      if (hotelName.substring(0, 1) !='[a-zA-Z]*') {
        status = true;
      } else {
        // var str = hotelId.substring(1);
        // if (isNaN(num))
          // status = true;
      }
      if (status)
        formGroup.controls.hotelName.setErrors({ 'hotelIdValidator': true });
      else
        formGroup.controls.hotelName.setErrors(null);
    }
  }
  ngOnInit(): void {
    this.getAllHotels();
    document.body.classList.add('bg-img');
  }

  getAllHotels() {
    this.hs.getAllHotels().subscribe((data) => {
      console.log(data);
      this.hotels = data;
    });
  }

  fnSelect(hotelId) {
    this.hs.findHotelById(hotelId).subscribe((data) => {
      console.log(data);
      // alert(JSON.stringify(data))
      this.hotelForm.patchValue(data);
    });
  }


  fnFind() {
    var hotelId = this.hotelForm.controls.hotelId.value;
    this.fnSelect(hotelId);
  }

  fnFindCityByCity()
  {
    var city=this.hotelForm.controls.city.value;
    console.log("Finding hotels by city: "+city);
    this.hs.findHotelByCity(city).subscribe((data)=>{
      console.log("Found hotels by city:"+city);
      console.log(data);
      this.hotels=data;
    })
  }
  fnAdd() {
    var hotel = this.hotelForm.value;
    // this.bs.addHotel(hotel).subscribe(this.fnCallBack);    
    this.hs.addHotel(hotel).subscribe((data) => {
      console.log(data);
      this.getAllHotels();
    });
  }
  fnModify() {
    var hotel = this.hotelForm.value;
    this.hs.modifyHotel(hotel).subscribe((data) => {
      console.log(data);
      this.getAllHotels();
    });
  }
  fnDelete() {
    var hotelId = this.hotelForm.controls.hotelId.value;
    this.hs.deleteHotel(hotelId).subscribe((data) => {
      console.log(data);
      this.getAllHotels();
    });
  }

  get form()
    {
      return this.hotelForm.controls;
    }

}
