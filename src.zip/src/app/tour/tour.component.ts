import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TourService } from '../tour.service';


@Component({
  selector: 'app-tour',
  templateUrl: './tour.component.html',
  styleUrls: ['./tour.component.css']
})
export class TourComponent implements OnInit {

  tourForm: any;
  gotp:any;
  otpError:any;

  guides: any;

constructor(private fb: FormBuilder, private bs: TourService) {
  this.tourForm = this.fb.group({
    guideId: [''],
    customerId: [''],
    guideName: [''],
    guidePhoneNo: ['',[Validators.required, Validators.minLength(10), Validators.maxLength(10),Validators.pattern]]
  },{validators:this.guidePhoneNoValidator()});
}
guidePhoneNoValidator() {
  return (formGroup: FormGroup) => {
    if (formGroup.controls.guidePhoneNo.errors && !formGroup.controls.guidePhoneNo.errors.guidePhoneNoValidator)
      return;
    var status = true;
    var guidePhoneNo = formGroup.controls.guidePhoneNo.value;

    if (guidePhoneNo.substring(0, 1) != 'B') {
      status = true;
    } else {
      var num = guidePhoneNo.substring(1);
      if (isNaN(num))
        status = true;
    }
    if (status)
      formGroup.controls.guidePhoneNo.setErrors({ 'guidePhoneNoValidator': true });
    else
      formGroup.controls.guidePhoneNo.setErrors(null);
  }
}
get form() {
  return this.tourForm.controls;
}


ngOnInit(): void {
  this.getAllGuides();
}


getAllGuides() {
  this.bs.getAllGuides().subscribe((data) => {
    console.log(data);
    this.guides = data;
  });
}

fnSelect(guideId) {
  this.bs.findGuideById(guideId).subscribe((data) => {
    console.log(data);
    // alert(JSON.stringify(data))
    this.tourForm.patchValue(data);
  });
}


fnFind()
{
  var bookingId=this.tourForm.controls.bookingId.value;
  this.bs.findGuideById(bookingId).subscribe((data)=>{
    console.log(data);
   this.tourForm.patchValue(data);
});
}
fnAdd() {
  var guide = this.tourForm.value;  
  console.log(this.tourForm.value);
    var formData=new FormData();
    
    formData.append('guideId',this.tourForm.controls.guideId.value);
    formData.append('customerId',this.tourForm.controls.customerId.value);
    formData.append('guideName',this.tourForm.controls.guideName.value);
    formData.append('guidePhoneNo',this.tourForm.controls.guidePhoneNo.value);
    
    
    // this.us.addtour(formData).subscribe(data=>{
    //   console.log(data);
    // })
  // }
  this.bs.addGuide(formData).subscribe((data) => {
    console.log(data);
    this.getAllGuides();

  });
}
fnModify() {
  var guide = this.tourForm.value;
  var formData=new FormData();
    
    formData.append('guideId',this.tourForm.controls.guideId.value);
    formData.append('customerId',this.tourForm.controls.customerId.value);
    formData.append('guideName',this.tourForm.controls.guideName.value);
    formData.append('guidePhoneNo',this.tourForm.controls.guidePhoneNo.value);
    
    
    // this.us.addtour(formData).subscribe(data=>{
    //   console.log(data);
    // })
  // }
  this.bs.addGuide(formData).subscribe((data) => {
    console.log(data);
    this.getAllGuides();

  });
}
fnDelete() {
  var guideId = this.tourForm.controls.guideId.value;
  this.bs.deleteGuide(guideId).subscribe((data) => {
    console.log(data);
    this.getAllGuides();
  });
  //   var eotp=this.signupForm.controls.enteredOtp.value;
  //   alert('comparing '+eotp+' with '+this.gotp);
  //  // alert('adding...');
  //  if(eotp!=this.gotp)
  //  {
  //   this.otpError="Entered otp is invalid";
  //    return;
  //  }
   
//   fnGeneratePhoneNo()
//   {
//     //under construction
//     var emailAddress=this.tourForm.controls.emailAddress.value;
//     console.log(emailAddress);
//     this.bs.fnGeneratePhoneNo(emailAddress).subscribe((data)=>{
//       console.log(data);
//       this.gotp=data;      
//     });
//     // this.signupForm.controls.generatedOtp.value=this.gotp;
//   }
// }

}
}
